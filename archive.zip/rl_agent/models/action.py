class Action:
    BUY = "BUY"
    SELL = "SELL"
    HOLD = "HOLD"
