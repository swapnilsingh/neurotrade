class CooldownManager:
    def __init__(self, enabled=True, cooldown_seconds=2):
        self.enabled = enabled
        self.cooldown_seconds = cooldown_seconds
        self.last_trade_time = 0

    def can_trade(self, timestamp):
        if not self.enabled:
            return True
        if timestamp - self.last_trade_time >= self.cooldown_seconds * 1000:
            self.last_trade_time = timestamp
            return True
        return False
