# inference/inference_runner.py

import asyncio
import logging
import redis.asyncio as aioredis

from core.decorators import inject_logger, inject_config
from utils.config_helpers import format_redis_keys
from utils.config_loader import load_config

from inference.dynamic_tick_essemble_agent import DynamicTickEnsembleAgent
from inference.reward_evaluator import RewardEvaluator
from inference.reward_agent import RewardAgent
from inference.evaluator_agent import EvaluatorAgent
from inference.tick_stream_listener import TickStreamListener
from inference.cooldown_manager import CooldownManager
from inference.tick_processor import TickProcessor
from inference.state_builder import StateBuilder
from inference.trade_executor import TradeExecutor
from inference.experience_manager import ExperienceManager
from inference.summary_publisher import SummaryPublisher
from inference.state_tracker import StateTracker


@inject_logger()
@inject_config("configs/inference.yaml")
class InferenceRunner:
    def __init__(self):
        self.symbol = self.config["symbol"].lower()
        self.min_ticks = self.config["min_ticks_for_state"]
        self.tick_buffer_size = self.config.get("tick_buffer_size", 100)

        redis_config = load_config("configs/redis.yaml")
        self.redis_conn = aioredis.Redis(
            host=redis_config["host"],
            port=redis_config["port"],
            decode_responses=True
        )

        # Agents
        self.evaluator = EvaluatorAgent()
        self.reward_agent = RewardAgent(self.evaluator)
        self.dqn_agent = DynamicTickEnsembleAgent()

        # Modules
        self.tick_listener = TickStreamListener()
        self.cooldown_manager = CooldownManager()
        self.state_tracker = StateTracker()
        self.tick_processor = TickProcessor(self.tick_listener)
        self.state_builder = StateBuilder(self.evaluator, self.state_tracker)
        self.trade_executor = TradeExecutor(self.state_tracker)
        self.reward_evaluator = RewardEvaluator(self.reward_agent, self.tick_listener, self.state_tracker)
        self.experience_manager = ExperienceManager(self.redis_conn)
        self.summary_publisher = SummaryPublisher(self.redis_conn, self.state_tracker)

        self.logger.info(f"✅ Inference initialized for {self.symbol.upper()}")

    async def run(self):
        self.logger.info("🚀 Starting inference loop...")
        asyncio.create_task(self.tick_listener.connect())

        try:
            while True:
                await asyncio.sleep(0.5)
                await self.run_tick_cycle()
        except (asyncio.CancelledError, KeyboardInterrupt):
            self.logger.info("🛑 Inference stopped gracefully.")

    async def run_tick_cycle(self):
        if not self.tick_processor.has_enough_ticks():
            return

        state, current_price, ts = self.state_builder.build()
        signal, votes, qty, tp_pct, suggestion = self.dqn_agent.vote(state)

        self.logger.info(f"🧠 Signal: {signal} | Price: {current_price:.2f} | Suggestion: {suggestion}")

        if self.cooldown_manager.enabled and not self.cooldown_manager.can_trade(ts):
            self.logger.debug("⏳ Cooldown active. Holding.")
            signal = "HOLD"

        reason = self.trade_executor.execute(signal, current_price, qty)
        reward = self.reward_evaluator.compute(current_price, signal, qty)
        future_state = self.state_builder.build_future()

        self.experience_manager.push(
            state, future_state, qty, signal, reward,
            ts, reason, tp_pct, suggestion, current_price
        )

        await self.summary_publisher.publish(current_price, ts)


if __name__ == "__main__":
    asyncio.run(InferenceRunner().run())
