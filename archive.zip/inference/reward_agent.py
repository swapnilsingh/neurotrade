# inference/reward_agent.py

import logging
import numpy as np
from utils.reward import compute_reward_from_ticks
from utils.config_loader import load_config

logger = logging.getLogger("RewardAgent")

class RewardAgent:
    def __init__(self, evaluator_agent, config=None):
        self.evaluator_agent = evaluator_agent
        self.config = config or load_config("configs/reward_agent.yaml")
        self.use_dynamic_volatility = self.config.get("use_dynamic_volatility", True)

    def compute(self, ticks, signal, quantity, current_price, entry_price, position, inventory_ratio):
        base_reward = compute_reward_from_ticks(
            ticks=ticks,
            signal=signal,
            quantity=quantity,
            current_price=current_price,
            entry_price=entry_price,
            position=position,
            use_dynamic_volatility=self.use_dynamic_volatility,
            inventory_ratio=inventory_ratio
        )

        feedback = self.evaluator_agent.generate_feedback()

        exploration_bonus = 0.001 if signal in ["BUY", "SELL"] else 0.0

        shaped_reward = (base_reward + exploration_bonus)
        shaped_reward *= feedback.get("reward_bonus_booster", 1.0)
        shaped_reward /= feedback.get("penalty_aggressiveness", 1.0)

        logger.debug(f"[RewardAgent] Reward: {shaped_reward:.5f} | Base: {base_reward:.5f} | Bonus: {exploration_bonus}")
        return shaped_reward, feedback
